import React from 'react'
import MoreNewest from '../Components/Newest/MoreNewest'

function Newests() {
  return (
    <div>
      <MoreNewest/>
    </div>
  )
}

export default Newests