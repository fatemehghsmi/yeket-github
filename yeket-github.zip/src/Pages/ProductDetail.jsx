import React from 'react'
import CardDetail from '../Components/CardDetail/CardDetail'

function ProductDetail() {
  return (
    <div style={{width:"95%"}}>
        <CardDetail/>
    </div>
  )
}

export default ProductDetail